import argparse
import requests

def fetch_status(base_url):
    resp = requests.get(f"{base_url}/status")
    return resp.json()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--url', required=True, help='Base URL of app')
    parser.add_argument('--check-status', action='store_true')
    args = parser.parse_args()

    if args.check_status:
        status = fetch_status(args.url)
        print(f"App Status: {status}")

if __name__ == '__main__':
    main()
