# Prompt Evaluation Framework — Competitive Research

## OpenAI

- Evaluates prompts on helpfulness, correctness, harmlessness
- Measures latency, token usage, and quality
- Uses reinforcement learning with human feedback (RLHF)
- Best practices: prompt versioning, few-shot examples, chain-of-thought

## Lovable AI

- Tracks failure types (hallucination, irrelevant, OOM)
- Groups failed prompts for batch testing
- Monitors success rate across model updates

## Lessons for Lex-AI

- Add automatic success/failure tagging to prompt logs
- Track latency and group by prompt type
- Use logs to detect common issues (e.g., format, rate limit, hallucinations)
