# Metrics Dashboard

## Purpose
This dashboard tracks key metrics related to the health and performance of the application monitoring system.

## Metrics Tracked
- App status (running, failed, etc.)
- API response times
- Error rates
- Logs processed
- Latency bands for prompt evaluation

## How Metrics Are Collected
Metrics are collected via scripts and APIs that monitor deployed apps.

## How to Update This Dashboard
Run the monitoring scripts located in `monitoring/monitor.py` to refresh metrics.

## Viewing Metrics
Metrics can be viewed in:
- CLI output
- Generated reports
- Dashboards (if applicable)

---

*Last updated: [July 1]*

---

### 🔄 Latest Metrics (2025-07-01 18:00):
- App Status: running
- Build Time: 125s
- Error Count: 3
- Success: True

#### Error Types
| Error Type     | Count |
|----------------|-------|
| timeout        | 2     |
| out of memory  | 0     |
| invalid format | 1     |
| rate limit     | 0     |
| 500 error      | 0     |

#### Prompt Latency Band
- Last Prompt Latency: `500–1000ms`

### 🔄 Latest Metrics (2025-07-02 16:09):
- App Status: Connection error: HTTPConnectionPool(host='127.0.0.1', port=8880): Max retries exceeded with url: /status (Caused by NewConnectionError('<urllib3.connection.HTTPConnection object at 0x1050a3430>: Failed to establish a new connection: [Errno 61] Connection refused'))
- Build Time: 128
- Error Count: 0
- Success: True

#### Error Types
| Error Type     | Count |
|----------------|-------|
| timeout | 0 |
| out of memory | 0 |
| invalid format | 0 |
| rate limit | 0 |
| 500 error | 0 |

#### Prompt Latency Band
- Last Prompt Latency: `1000–2000ms`
