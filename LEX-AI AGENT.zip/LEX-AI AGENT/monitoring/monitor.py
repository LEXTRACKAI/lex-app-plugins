# monitor.py

import argparse
import requests
import os
from datetime import datetime
import time
import random  # Simulates prompt response delay

def get_status_from_backend(port=8880):
    """Fetch app status from the running FastAPI backend."""
    try:
        response = requests.get(f"http://127.0.0.1:{port}/status")
        if response.status_code == 200:
            return response.json()
        else:
            return {"status": f"Error: {response.status_code}"}
    except requests.exceptions.RequestException as e:
        return {"status": f"Connection error: {e}"}

def parse_log_file(filepath):
    """Extract metrics and parse common errors from a log file."""
    if not os.path.exists(filepath):
        print(f"❌ Error: File '{filepath}' not found.")
        return {"build_time": None, "error_count": None, "success": None, "error_summary": {}}

    with open(filepath, "r") as f:
        lines = f.readlines()

    build_time = None
    error_count = None
    success = None

    # Keyword parsing
    error_keywords = ["timeout", "out of memory", "invalid format", "rate limit", "500 error"]
    error_counts = {key: 0 for key in error_keywords}

    for line in lines:
        line_lower = line.lower()

        if "build time:" in line_lower:
            build_time = line.split("Build Time:")[-1].strip()
        elif "error count:" in line_lower:
            error_count = line.split("Error Count:")[-1].strip()
        elif "success:" in line_lower:
            success = line.split("Success:")[-1].strip()

        for keyword in error_keywords:
            if keyword in line_lower:
                error_counts[keyword] += 1

    return {
        "build_time": build_time,
        "error_count": error_count,
        "success": success,
        "error_summary": error_counts
    }

def display_metrics(metrics, status):
    print("\n📊 Metrics Summary:")
    print(f"- App Status: {status['status']}")
    print(f"- Build Time: {metrics['build_time']}")
    print(f"- Error Count: {metrics['error_count']}")
    print(f"- Success: {metrics['success']}")

    if metrics.get("error_summary"):
        print("\n🔍 Error Breakdown:")
        for keyword, count in metrics["error_summary"].items():
            print(f"  • {keyword}: {count}")

def update_dashboard_md(metrics, status, latency_band=None):
    dashboard_path = "metrics_dashboard.md"
    if not os.path.exists(dashboard_path):
        print("⚠️  metrics_dashboard.md not found, skipping update.")
        return

    with open(dashboard_path, "a") as f:
        f.write(f"\n### 🔄 Latest Metrics ({datetime.now().strftime('%Y-%m-%d %H:%M')}):\n")
        f.write(f"- App Status: {status['status']}\n")
        f.write(f"- Build Time: {metrics['build_time']}\n")
        f.write(f"- Error Count: {metrics['error_count']}\n")
        f.write(f"- Success: {metrics['success']}\n")

        # Error Types Table
        if metrics.get("error_summary"):
            f.write("\n#### Error Types\n")
            f.write("| Error Type     | Count |\n")
            f.write("|----------------|-------|\n")
            for keyword, count in metrics["error_summary"].items():
                f.write(f"| {keyword} | {count} |\n")

        # Latency Band
        if latency_band:
            f.write("\n#### Prompt Latency Band\n")
            f.write(f"- Last Prompt Latency: `{latency_band}`\n")

def measure_prompt_latency(prompt):
    """Simulate or measure real prompt latency."""
    start_time = time.time()

    # Simulate API delay — replace this with a real model call
    time.sleep(random.uniform(0.4, 1.2))
    response = f"Simulated response for prompt: {prompt}"

    end_time = time.time()
    inference_time = round(end_time - start_time, 3)

    # Latency Band Bucketing
    if inference_time < 0.5:
        latency_band = "< 500ms"
    elif inference_time < 1:
        latency_band = "500–1000ms"
    elif inference_time < 2:
        latency_band = "1000–2000ms"
    else:
        latency_band = "> 2000ms"

    print(f"\n🕒 Inference Time: {inference_time}s")
    print(f"📉 Latency Band: {latency_band}")

    return response, inference_time, latency_band

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--logfile", type=str, help="Path to log file", required=True)
    parser.add_argument("--port", type=int, default=8880, help="Backend API port (default: 8880)")
    parser.add_argument("--update-md", action="store_true", help="Update metrics_dashboard.md with new values")
    parser.add_argument("--test-prompt", action="store_true", help="Run prompt latency simulation")
    args = parser.parse_args()

    print("📂 Reading local log file...")
    metrics = parse_log_file(args.logfile)
    status = get_status_from_backend(port=args.port)
    display_metrics(metrics, status)

    # Optional prompt latency test
    if args.test_prompt:
        prompt = "What is the capital of France?"
        response, latency, latency_band = measure_prompt_latency(prompt)
        print(f"🔁 Simulated Prompt Response: {response}")
    else:
        latency_band = None

    # Optional markdown update
    if args.update_md:
        update_dashboard_md(metrics, status, latency_band)
