import chardet

with open("Maliha_log_1.txt", "rb") as f:
    rawdata = f.read()
    result = chardet.detect(rawdata)
    print(result)
