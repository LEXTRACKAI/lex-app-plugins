import pandas as pd
import re

# Expected format:
# [YYYY-MM-DD HH:MM:SS] app_id=<name> status=<status> <optional_error_type> latency=<float> tokens=<int>

def parse_logs(filepath):
    pattern = r"\[(.*?)\] app_id=(\S+) status=(\S+)(?: (\S+))? latency=(\S+) tokens=(\d+)"
    data = []

    with open(filepath, 'r') as file:
        for line in file:
            match = re.match(pattern, line)
            if match:
                timestamp, app_id, status, error_type, latency, tokens = match.groups()
                data.append({
                    "timestamp": pd.to_datetime(timestamp),
                    "app_id": app_id,
                    "status": status,
                    "error_type": error_type if error_type else "None",
                    "latency": float(latency),
                    "tokens_used": int(tokens)
                })

    return pd.DataFrame(data)

# Optional: Run this file directly to test it
if __name__ == "__main__":
    df = parse_logs("sample_log.txt")
    print(df.head())
