import streamlit as st
import chardet
import pandas as pd

st.set_page_config(page_title="LLM Log Analyzer", layout="centered")
st.title("📊 LLM App Log Analyzer")

# File upload
uploaded_file = st.file_uploader("Upload your log file (.txt)", type=["txt"])

if uploaded_file:
    # Detect encoding
    raw_data = uploaded_file.read()
    encoding = chardet.detect(raw_data)['encoding']
    st.write(f"📎 Detected Encoding: `{encoding}`")

    try:
        text = raw_data.decode(encoding)
        lines = text.splitlines()
        
        # Extract response times from log
        times = []
        success_count = 0
        error_count = 0

        for line in lines:
            if "Time taken" in line:
                parts = line.split(":")
                if len(parts) > 1:
                    ms = parts[-1].strip().replace("ms", "")
                    try:
                        times.append(float(ms))
                    except:
                        pass
            if '"POST /translate' in line:
                if '"200 OK"' in line:
                    success_count += 1
                elif '"400 Bad Request"' in line:
                    error_count += 1

        if times:
            df = pd.DataFrame(times, columns=["Response Time (ms)"])

            st.subheader("📈 Performance Metrics")
            st.metric("✅ Successful Requests", success_count)
            st.metric("❌ Failed Requests (400)", error_count)
            st.metric("⏱️ Average Latency (ms)", f"{sum(times)/len(times):.2f}")

            st.line_chart(df)
            st.dataframe(df)

        else:
            st.warning("No response time data found in this log.")

    except Exception as e:
        st.error(f"Error decoding or parsing log: {e}")
